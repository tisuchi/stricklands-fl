<?php $__env->startSection('content'); ?>



<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/datatable/datatables.min.css')); ?>">

<!-- Main Content begin -->

<div class="app-content content">
    <div class="content-wrapper">
      
			<div class="content-header row">
				<div class="col-12">
				<h1>Vehicle Inventory <?php echo e(!empty($numberofdays)? "- Last $numberofdays Days" : ''); ?> </h1>
				</div>
			</div>

			
      <div class="content-body">

        <section id="configuration">
        	<form method="GET" action="<?php echo e(route('inventory-search')); ?>">
        		<?php if($numberofdays == 4): ?>
        			<input type="hidden" value="Y" name="vFourDays" />
        		<?php endif; ?> 
        		<?php if($numberofdays == 14): ?>
					<input type="hidden" value="Y" name="v14Days" />
        		<?php endif; ?>
					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<select class="select2 form-control block" id="sel_location" name="vLoc">
									<option value="all">All Locations</option>
									<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($location->fldCode); ?>" <?php if(Request::input('vLoc') == $location->fldCode): ?> selected="selected" <?php endif; ?>><?php echo e($location->fldLocationName); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<select class="select2 form-control block" id="sel_inventory" name="vNewUsed">
									<option value="all">All Inventory</option>
									<?php $__currentLoopData = $statuscodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($code->fld_code); ?>" <?php if(Request::input('vNewUsed') == $code->fld_code): ?> selected="selected" <?php endif; ?>><?php echo e($code->fld_desc); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<select class="select2 form-control block" id="sel_type" name="vType">
									<option value="all">All Types</option>
									<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($type->fldCode); ?>" <?php if(Request::input('vType') == $type->fldCode): ?> selected="selected" <?php endif; ?>><?php echo e($type->fldDesc); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<select class="select2 form-control block" id="sel_price" name="vRetail">
									<option value="180000" selected="selected">All Prices</option>
									<option value="30000" <?php if(Request::input('vRetail') == 30000): ?> selected="selected" <?php endif; ?>>Under $30,000</option>
									<option value="25000" <?php if(Request::input('vRetail') == 25000): ?> selected="selected" <?php endif; ?>>Under $25,000</option>
									<option value="20000" <?php if(Request::input('vRetail') == 20000): ?> selected="selected" <?php endif; ?>>Under $20,000</option>
									<option value="15000" <?php if(Request::input('vRetail') == 15000): ?> selected="selected" <?php endif; ?>>Under $15,000</option>
									<option value="10000" <?php if(Request::input('vRetail') == 10000): ?> selected="selected" <?php endif; ?>>Under $10,000</option>
									<option value="5000" <?php if(Request::input('vRetail') == 5000): ?> selected="selected" <?php endif; ?>>Under $5,000 </option>
						            
								</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<select class="select2 form-control block" id="sel_ordermeter" name="vOdometer">
									<option value="All">All KM's</option>
									<option value="50000" <?php if(Request::input('vOdometer') == 50000): ?> selected="selected" <?php endif; ?>>Under 50,000</option>
									<option value="75000" <?php if(Request::input('vOdometer') == 75000): ?> selected="selected" <?php endif; ?>>Under 75,000</option>
									<option value="100000" <?php if(Request::input('vOdometer') == 100000): ?> selected="selected" <?php endif; ?>>Under 100,000</option>
									<option value="125000" <?php if(Request::input('vOdometer') == 125000): ?> selected="selected" <?php endif; ?>>Under 125,000</option>
									<option value="150000" <?php if(Request::input('vOdometer') == 150000): ?> selected="selected" <?php endif; ?>>Under 150,000</option>
									<option value="200000" <?php if(Request::input('vOdometer') == 200000): ?> selected="selected" <?php endif; ?>>Under 200,000 </option>
								</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<select class="select2 form-control block" id="sel_year" name="vYear">
									<option value="all">All Years</option>
          							<?php $__currentLoopData = range(date('Y'), date('Y')-20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          								<option value="<?php echo e($year); ?>" <?php if(Request::input('vYear') == $year): ?> selected="selected" <?php endif; ?>><?php echo e($year); ?></option>
          							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<select class="select2 form-control block" id="sel_make" name="vMake">
									<option value="all">All Makes</option>
									<?php $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          								<option value="<?php echo e($make->fldMake); ?>" <?php if(Request::input('vMake') == $make->fldMake): ?> selected="selected" <?php endif; ?>><?php echo e($make->fldMake); ?></option>
          							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						
						<div class="col-md-2">
								<input type="text" class="form-control" id="sel_model" placeholder="Model" name="vModel" <?php if(Request::input('vStock')): ?> value="<?php echo e(Request::input('vStock')); ?>" <?php endif; ?>>
						</div>
						
						<div class="col-md-2">
								<input type="text" class="form-control" id="sel_stocknum" placeholder="Stock#" name="vStock" <?php if(Request::input('vStock')): ?> value="<?php echo e(Request::input('vStock')); ?>" <?php endif; ?>>
						</div>
						
						<div class="col-md-2">
							<button type="submit" class="btn btn-primary" name="filter" value="submitted">
								<i class="fa fa-check-square-o"></i> Filter
							</button>
						</div>
					</div>

			</form>
					
					
          <div class="row">
            <div class="col-12">
              <div class="card">
                
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">
                    
                    <table class="table nowrap table-striped table-bordered scroll-horizontal table-responsive-sm table-xs compact" cellspacing="0" width="100%">
                      <thead>
                        <tr>
							<th></th>
							<th>Vehicle</th>
							<th></th>
							<th>Stock</th>
							<th>L</th>
							<th>Days</th>
							<th>Vin</th>
							<th>Engine</th>
							<th>Trans</th>
							<th>Colour</th>
							<th>Features</th>
							<th>KM's</th>
							<th>Price</th>
                        </tr>
                      </thead>
                      <tbody>
						
							<?php if( count($vehicles) > 0 ): ?>
								<?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                      	<tr>
			                          	<td>
			                          		<i class="fa fa-hand-o-up"></i>
			                          	</td>
										<td> 

											<a class="call-pop-over-function call-modal" href="?<?php echo e($vehicle->fldStockNo); ?>" data-toggle="modal" data-id="<?php echo e($vehicle->fldStockNo); ?>" id="popover-<?php echo e($vehicle->fldStockNo); ?>" data-trigger="hover" data-placement="right" data-container="body" data-original-title="<?php echo e($vehicle->fldYear ." ". $vehicle->fldMake ." ". $vehicle->fldModel ." ". $vehicle->fldModelNo); ?>" data-content="STK# <?php echo e($vehicle->fldStockNo); ?> || Notes: <?php echo e($vehicle->fldComments); ?>" data-target="#default-<?php echo e($vehicle->fldStockNo); ?>">
												<?php 
													if(substr($vehicle->fldYear ." ". $vehicle->fldMake ." ". $vehicle->fldModel ." ". $vehicle->fldModelNo, 0, 20) == false){
														echo $vehicle->fldYear ." ". $vehicle->fldMake ." ". $vehicle->fldModel ." ". $vehicle->fldModelNo;
													} else {
														echo substr($vehicle->fldYear ." ". $vehicle->fldMake ." ". $vehicle->fldModel ." ". $vehicle->fldModelNo, 0, 20) . "...";														
													}
												?>
											</a> 
										</td>
										

								
										
										<div class="modal fade text-left" id="default-<?php echo e($vehicle->fldStockNo); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" style="display: none;" aria-hidden="true">
											  <div class="modal-dialog modal-lg" role="document">
												<div class="modal-content">
												  <div class="modal-header">
													<h4 class="modal-title" id="myModalLabel1">
														<?php echo e($vehicle->fldYear); ?> <?php echo e($vehicle->fldMake); ?> <?php echo e($vehicle->fldModel); ?> <?php echo e($vehicle->fldModelNo); ?> - $<?php echo e($vehicle->fldRetail); ?>

													</h4>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													  <span aria-hidden="true">×</span>
													</button>
												  </div>
												  <div class="modal-body">
													<div class="row">
														<div class="col-sm-6">
															<div class="card">
																<div class="card-content">
																	<div class="card-body">
																		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
																			
																			
																			<div class="carousel-inner" role="listbox">
																				
																				
																				

																				<?php 
																					
																					for ($i=2;$i<=3;$i++)
																			        {
																			        	/*$name = "/home/adminstrick/images.stricklands.com/vin/";
																						$name .= $row_rs_list['fldStockNo'];						
																						$name .= "-" . $i . ".jpg";*/
																			        	//if (@GetImageSize($name)) {}
																			            $name = "http://images.stricklands.com/vin/$vehicle->fldStockNo-".$i . ".jpg";
																			            if ($i == 2) {
																			            	echo '<div class="carousel-item active">';
																			            } else {
																			            	echo '<div class="carousel-item">';
																			            }
																			            	echo '<img src="'.$name.'" alt="" width="500" height="375"/>';
																			            	echo '</div>';
																			        }
																			        
																				?>

																				<div class="carousel-item">
																					<img src="http://images.stricklands.com/vin/G180337-3.jpg" alt="First slide" width='500' height='375'>
																				</div> 

																				<div class="carousel-item">
																					<img src="http://images.stricklands.com/vin/G180337-4.jpg" alt="First slide" width='500' height='375'>
																				</div> 

																				<div class="carousel-item">
																					<img src="http://images.stricklands.com/vin/G180337-5.jpg" alt="First slide" width='500' height='375'>
																				</div> 

																				<div class="carousel-item">
																					<img src="http://images.stricklands.com/vin/G180337-6.jpg" alt="First slide" width='500' height='375'>
																				</div> 
																				
																			</div>
																			<a class="carousel-control-prev" href="#carousel-example-generic" role="button" data-slide="prev">
																				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
																				<span class="sr-only">Previous</span>
																			</a>
																			<a class="carousel-control-next" href="#carousel-example-generic" role="button" data-slide="next">
																				<span class="carousel-control-next-icon" aria-hidden="true"></span>
																				<span class="sr-only">Next</span>
																			</a>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<div class="col-sm-6">
															<h3>Vehicle Details</h3>
															<hr>
														
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Stock#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldStockNo); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Short Vin#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldShortVINNo); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Vin#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldVINNo); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Color#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldExteriorColor); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Engine#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldCyl); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Transmission#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldTransmission); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">KM's#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldOdometer); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Price#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldOdometer); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Location#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldLocationCode); ?>

																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Website URL#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<a class="text-success" href="http://www.stricklands.com/detail.php?stockno=<?php echo e($vehicle->fldStockNo); ?>" target="_blank">Website Link</a>
																	</span>
																</div>
															</div>
															
															
															<div class="row">
																<div class="col-sm-4">
																	<span class="text-primary text-bold">Info#:</span>
																</div>
																<div class="col-sm-8">
																	<span class="text-left">
																		<?php echo e($vehicle->fldComments); ?>

																	</span>
																</div>
															</div>

														</div>
													</div>
												  </div>
												  
												</div>
											  </div>
											</div>
										</div>

										<td>
											<a href="" data-toggle="modal" data-target="#default-<?php echo e($vehicle->fldStockNo); ?>" style="color: #000;">
												<center>
													<img src="<?php echo e(env('BASE_URL')); ?>/images/icon.png" alt="">
												</center>
											</a>
										</td>
										<td><?php echo e($vehicle->fldStockNo); ?> </td>
										<td><?php echo e($vehicle->fldLocationCode); ?> </td>
										<td> <?php echo e(round((strtotime(date('Y-m-d')) - strtotime($vehicle->fldDateReceived)) / (60 * 60 * 24), 0, PHP_ROUND_HALF_DOWN)); ?></td>
										
										<td><?php echo e($vehicle->fldShortVINNo); ?></td>
										<td><?php echo e($vehicle->fldCyl); ?></td>
										<td><?php echo e($vehicle->fldTransmission); ?></td>
										<td><?php echo e($vehicle->fldExteriorColor); ?></td>
										<td><?php echo e(substr($vehicle->fldAllCodes, 0, 10)); ?></td>
										<td><?php echo e($vehicle->fldOdometer); ?></td>
										<td><?php echo e($vehicle->fldRetail); ?></td>
			                        </tr>
		                       	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        <?php endif; ?>
                      </tbody>
                      <tfoot>
                        <tr>
                          <th></th>
							<th>Vehicle</th>
							<th></th>
							<th>Stock</th>
							<th>L</th>
							<th>Days</th>
							<th>Vin</th>
							<th>Engine</th>
							<th>Trans</th>
							<th>Colour</th>
							<th>Features</th>
							<th>KM's</th>
							<th>Price</th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
    </div>
</div>



<script src="<?php echo e(asset('admin_assets/js/mainjs/inventory_search.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/tables/datatables/datatable-basic.js')); ?>" type="text/javascript"></script>

<script>


	$('.call-pop-over-function').hover(
		function() {
			var id = $( this ).attr("data-id");
			$("#popover-"+id).popover({ trigger: "hover" });
		}
	);


	$('.call-modal').hover(
		function() {
			var id = $( this ).attr("data-id");
			$("#popover-"+id).popover({ trigger: "hover" });
		}
	);


</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>