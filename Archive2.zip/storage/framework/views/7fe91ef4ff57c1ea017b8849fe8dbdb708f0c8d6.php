<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Print Preview</title>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<style>
		table{
			font-size: 12px;
		}
		table > tr {
			padding: 2px auto;
		}
		.table td, .table th{
			padding: 0 10px !important;
			margin: 0;
			
		}
	</style>
</head>
<body>

<div class="row px-5" style="background: #CCCCCC;">
		<div class="col-sm-12" style="padding: 10px;">
			<div style="background: #fff;">
				<div class="row" style="margin: 10px;">
					<div class="col-sm-12">
						<br>
						<div style="font-size: 12px;">
							<a href="<?php echo e(route('inventory-list-print-after-search')); ?>">Year/Make/Model - Back to List- <?php echo e($vehicles->count()); ?> Vehicles</a>
						</div>
						<br>
						<table class="table nowrap table-striped table-bordered table-hover scroll-horizontal table-responsive-sm table-xs compact" cellspacing="0" width="100%" border="1" style="">
						  <thead>
						    <tr>
								<th>Trader</th>
								<th>STK</th>
								<th>Loc</th>
								<th>VIN</th>
								<th>Color</th>
								<th>KM</th>
								<th>Price</th>
						    </tr>
						  </thead>
						  <tbody>
								<?php if( count($vehicles) > 0 ): ?>
									<?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						              	<tr>
						                  	<td class="text-left"><?php echo e($vehicle->fldYear); ?> <?php echo e($vehicle->fldMake); ?> <?php echo e($vehicle->fldModel); ?> <?php echo e($vehicle->fldModelNo); ?></td>
											<td><?php echo e($vehicle->fldStockNo); ?></td>
											<td><?php echo e($vehicle->fldLocationCode); ?></td>
											<td><?php echo e($vehicle->fldShortVINNo); ?></td>
											<td><?php echo e($vehicle->fldExteriorColor); ?></td>
											<td><?php echo e($vehicle->fldOdometer); ?></td>
											<td>$<?php echo e($vehicle->fldRetail); ?></td>
						                </tr>
						           	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						        <?php endif; ?>
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
</div>
	
</body>
</html>