@extends('admin.main')

@section('content')

<!-- Main Content begin -->

<div class="app-content content">
    <div class="content-wrapper">
      
			<div class="content-header row">
				<div class="col-12">
				<h1>Inventory Count</h1>
				</div>
			</div>
			
			<div class="row breadcrumbs-top">
				<div class="breadcrumb-wrapper col-12">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="{{$base_url}}admin">Home</a>
						</li>
						<li class="breadcrumb-item"><a href="{{$base_url}}admin/inventory/search">Inventory</a>
						</li>
						<li class="breadcrumb-item active">Inventory Count
						</li>
					</ol>
				</div>
			</div>
			
      <div class="content-body">

			</div>
    </div>
</div>

@stop