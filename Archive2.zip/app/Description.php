<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Description extends Model
{
    protected $table = 'a_tbl_descriptions';
    //public $timestamps = false;

}
