<?php $__env->startSection('content'); ?>



<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/datatable/datatables.min.css')); ?>">

<!-- Main Content begin -->

<div class="app-content content">
    <div class="content-wrapper">
      
			<div class="content-header row">
				<div class="col-12">
				<h1>Inventory Count</h1>
				</div>
			</div>
			
      <div class="content-body">

        <section id="configuration">
        			
					
          <div class="row">
            <div class="col-12">
              	
              	<div class="card">    
	                <div class="card-body card-dashboard">
	                    
	                    <h3 class="text-uppercase">New Vehicle</h3>
	                    <hr>
	                    <span class="text-bold-600">For Sale - Ready</span>
	                  	<div class="table-responsive">
		                    <table class="table table-bordered table-striped">
		                      <thead>
		                        <tr>
		                          <th>Cars</th>
		                          <th>SUVs</th>
		                          <th>Minivans</th>
		                          <th>Trucks</th>
		                          <th>Total</th>
		                        </tr>
		                      </thead>
		                      <tbody>
		                        <tr>
		                          <th><?php echo e($newreadyforsale['newreadycars']); ?></th>
		                          <td><?php echo e($newreadyforsale['newreadysuvs']); ?></td>
		                          <td><?php echo e($newreadyforsale['newreadyvans']); ?></td>
		                          <td><?php echo e($newreadyforsale['newreadytrucks']); ?></td>
		                          <td>
		                          		<?php echo e($newreadyforsale['newreadycars'] + $newreadyforsale['newreadysuvs'] + $newreadyforsale['newreadyvans'] + $newreadyforsale['newreadytrucks']); ?>

		                          </td>
		                        </tr>
		                      </tbody>
		                    </table>
	                  	</div>

						<br>
	                  	<span class="text-bold-600">Sold</span>
	                  	<div class="table-responsive">
		                    <table class="table table-bordered table-striped">
		                      <thead>
		                        <tr>
		                          <th>Cars</th>
		                          <th>SUVs</th>
		                          <th>Minivans</th>
		                          <th>Trucks</th>
		                          <th>Total</th>
		                        </tr>
		                      </thead>
		                      <tbody>
		                        <tr>
		                          <th><?php echo e($newsold['newsoldcars']); ?></th>
		                          <td><?php echo e($newsold['newsoldsuvs']); ?></td>
		                          <td><?php echo e($newsold['newsoldvans']); ?></td>
		                          <td><?php echo e($newsold['newsoldtrucks']); ?></td>
		                          <td>
		                          		<?php echo e($newsold['newsoldcars'] + $newsold['newsoldsuvs'] + $newsold['newsoldvans'] + $newsold['newsoldtrucks']); ?>

		                          </td>
		                        </tr>
		                      </tbody>
		                    </table>
	                  	</div>
	                </div>
              	</div>

              	<div class="card">            
	                <div class="card-body card-dashboard">
	                    
	                    <h3 class="text-uppercase">USED VEHICLES</h3>
	                    <hr>
	                    <span class="text-bold-600">For Sale - Ready</span>
	                  	<div class="table-responsive">
		                    <table class="table table-bordered table-striped">
		                      <thead>
		                        <tr>
		                          <th>Cars</th>
		                          <th>SUVs</th>
		                          <th>Minivans</th>
		                          <th>Trucks</th>
		                          <th>Total</th>
		                        </tr>
		                      </thead>
		                      <tbody>
		                        <tr>
		                          <th><?php echo e($usedreadyforsale['usedreadycars']); ?></th>
		                          <td><?php echo e($usedreadyforsale['usedreadysuvs']); ?></td>
		                          <td><?php echo e($usedreadyforsale['usedreadyvans']); ?></td>
		                          <td><?php echo e($usedreadyforsale['usedreadytrucks']); ?></td>
		                          <td>
		                          		<?php echo e($usedreadyforsale['usedreadycars'] + $usedreadyforsale['usedreadysuvs'] + $usedreadyforsale['usedreadyvans'] + $usedreadyforsale['usedreadytrucks']); ?>

		                          </td>
		                        </tr>
		                      </tbody>
		                    </table>
	                  	</div>

						<br>
	                  	<span class="text-bold-600">Sold</span>
	                  	<div class="table-responsive">
		                    <table class="table table-bordered table-striped table-xs">
		                      <thead>
		                        <tr>
		                          <th>Cars</th>
		                          <th>SUVs</th>
		                          <th>Minivans</th>
		                          <th>Trucks</th>
		                          <th>Total</th>
		                        </tr>
		                      </thead>
		                      <tbody>
		                        <tr>
		                          <th><?php echo e($usedsold['usedsoldcars']); ?></th>
		                          <td><?php echo e($usedsold['usedsoldsuvs']); ?></td>
		                          <td><?php echo e($usedsold['usedsoldvans']); ?></td>
		                          <td><?php echo e($usedsold['usedsoldtrucks']); ?></td>
		                          <td>
		                          		<?php echo e($usedsold['usedsoldcars'] + $usedsold['usedsoldsuvs'] + $usedsold['usedsoldvans'] + $usedsold['usedsoldtrucks']); ?>

		                          </td>
		                        </tr>
		                      </tbody>
		                    </table>
	                  	</div>
	                </div>
              	</div>

              	<div class="card">            
	                <div class="card-body card-dashboard">
	                    
	                    <h3 class="text-uppercase">USED INVENTORY PRICE AUDIT RESULTS</h3>
	                    <hr>
	                   	<ul class="nav nav-tabs">
	                      <li class="nav-item">
	                        <a class="nav-link active" id="base-tab1" data-toggle="tab" aria-controls="tab1" href="#tab1" aria-expanded="true">Stratford Automart</a>
	                      </li>
	                      <li class="nav-item">
	                        <a class="nav-link" id="base-tab2" data-toggle="tab" aria-controls="tab2" href="#tab2" aria-expanded="false">Toyota</a>
	                      </li>
	                      <li class="nav-item">
	                        <a class="nav-link" id="base-tab3" data-toggle="tab" aria-controls="tab3" href="#tab3" aria-expanded="false">GM</a>
	                      </li>
	                      <li class="nav-item">
	                        <a class="nav-link" id="base-tab3" data-toggle="tab" aria-controls="tab3" href="#tab4" aria-expanded="false">Windsor Automart</a>
	                      </li>
	                      <li class="nav-item">
	                        <a class="nav-link" id="base-tab3" data-toggle="tab" aria-controls="tab3" href="#tab5" aria-expanded="false">All</a>
	                      </li>
	                    </ul>

	                    <div class="tab-content px-1 pt-1">
	                      <div role="tabpanel" class="tab-pane active" id="tab1" aria-expanded="true" aria-labelledby="base-tab1">
	                        <div class="table-responsive">
			                    <table class="table table-bordered table-striped table-xs">
			                      <thead>
			                        <tr>
				                         <th></th>
				                         <th>$0-$10,000</th>
	                                     <th>$10-$15,000</th>
	                                     <th>$15-$20,000</th>
	                                     <th>$20-$25,000</th>
	                                     <th>$25,000+</th>
			                        </tr>
			                      </thead>
			                      <tbody>
			                        <tr>
			                          <th>Cars</th>
			                          <td><?php echo e($sacars['cars1']); ?></td>
			                          <td><?php echo e($sacars['cars2']); ?></td>
			                          <td><?php echo e($sacars['cars3']); ?></td>
			                          <td><?php echo e($sacars['cars4']); ?></td>
			                          <td><?php echo e($sacars['cars5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>SUVs</th>
			                          <td><?php echo e($sasuv['suv1']); ?></td>
			                          <td><?php echo e($sasuv['suv2']); ?></td>
			                          <td><?php echo e($sasuv['suv3']); ?></td>
			                          <td><?php echo e($sasuv['suv4']); ?></td>
			                          <td><?php echo e($sasuv['suv5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Minivans</th>
			                          <td><?php echo e($savan['van1']); ?></td>
			                          <td><?php echo e($savan['van2']); ?></td>
			                          <td><?php echo e($savan['van3']); ?></td>
			                          <td><?php echo e($savan['van4']); ?></td>
			                          <td><?php echo e($savan['van5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Trucks</th>
			                          <td><?php echo e($satruck['truck1']); ?></td>
			                          <td><?php echo e($satruck['truck2']); ?></td>
			                          <td><?php echo e($satruck['truck3']); ?></td>
			                          <td><?php echo e($satruck['truck4']); ?></td>
			                          <td><?php echo e($satruck['truck5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Total</th>
			                          <td>
			                          	<?php echo e($sacars['cars1'] + $sasuv['suv1'] + $savan['van1'] + $satruck['truck1']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($sacars['cars2'] + $sasuv['suv2'] + $savan['van2'] + $satruck['truck2']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($sacars['cars3'] + $sasuv['suv3'] + $savan['van3'] + $satruck['truck3']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($sacars['cars4'] + $sasuv['suv4'] + $savan['van4'] + $satruck['truck4']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($sacars['cars5'] + $sasuv['suv5'] + $savan['van5'] + $satruck['truck5']); ?>

			                          </td>
			                        </tr>
			                      </tbody>
			                    </table>
		                  	</div>
	                      </div>
	                      <div class="tab-pane" id="tab2" aria-labelledby="base-tab2">
	                        <div class="table-responsive">
			                    <table class="table table-bordered table-striped table-xs">
			                      <thead>
			                        <tr>
				                         <th></th>
				                         <th>$0-$10,000</th>
	                                     <th>$10-$15,000</th>
	                                     <th>$15-$20,000</th>
	                                     <th>$20-$25,000</th>
	                                     <th>$25,000+</th>
			                        </tr>
			                      </thead>
			                      <tbody>
			                        <tr>
			                          <th>Cars</th>
			                          <td><?php echo e($tcars['cars1']); ?></td>
			                          <td><?php echo e($tcars['cars2']); ?></td>
			                          <td><?php echo e($tcars['cars3']); ?></td>
			                          <td><?php echo e($tcars['cars4']); ?></td>
			                          <td><?php echo e($tcars['cars5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>SUVs</th>
			                          <td><?php echo e($tsuv['suv1']); ?></td>
			                          <td><?php echo e($tsuv['suv2']); ?></td>
			                          <td><?php echo e($tsuv['suv3']); ?></td>
			                          <td><?php echo e($tsuv['suv4']); ?></td>
			                          <td><?php echo e($tsuv['suv5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Minivans</th>
			                          <td><?php echo e($tvan['van1']); ?></td>
			                          <td><?php echo e($tvan['van2']); ?></td>
			                          <td><?php echo e($tvan['van3']); ?></td>
			                          <td><?php echo e($tvan['van4']); ?></td>
			                          <td><?php echo e($tvan['van5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Trucks</th>
			                          <td><?php echo e($ttruck['truck1']); ?></td>
			                          <td><?php echo e($ttruck['truck2']); ?></td>
			                          <td><?php echo e($ttruck['truck3']); ?></td>
			                          <td><?php echo e($ttruck['truck4']); ?></td>
			                          <td><?php echo e($ttruck['truck5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Total</th>
			                          <td>
			                          	<?php echo e($tcars['cars1'] + $tsuv['suv1'] + $tvan['van1'] + $ttruck['truck1']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($tcars['cars2'] + $tsuv['suv2'] + $tvan['van2'] + $ttruck['truck2']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($tcars['cars3'] + $tsuv['suv3'] + $tvan['van3'] + $ttruck['truck3']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($tcars['cars4'] + $tsuv['suv4'] + $tvan['van4'] + $ttruck['truck4']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($tcars['cars5'] + $tsuv['suv5'] + $tvan['van5'] + $ttruck['truck5']); ?>

			                          </td>
			                        </tr>
			                      </tbody>
			                    </table>
		                  	</div>
	                      </div>
	                      <div class="tab-pane" id="tab3" aria-labelledby="base-tab3">
	                        <div class="table-responsive">
			                    <table class="table table-bordered table-striped table-xs">
			                      <thead>
			                        <tr>
				                         <th></th>
				                         <th>$0-$10,000</th>
	                                     <th>$10-$15,000</th>
	                                     <th>$15-$20,000</th>
	                                     <th>$20-$25,000</th>
	                                     <th>$25,000+</th>
			                        </tr>
			                      </thead>
			                      <tbody>
			                        <tr>
			                          <th>Cars</th>
			                          <td><?php echo e($gmcars['cars1']); ?></td>
			                          <td><?php echo e($gmcars['cars2']); ?></td>
			                          <td><?php echo e($gmcars['cars3']); ?></td>
			                          <td><?php echo e($gmcars['cars4']); ?></td>
			                          <td><?php echo e($gmcars['cars5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>SUVs</th>
			                          <td><?php echo e($gmsuv['suv1']); ?></td>
			                          <td><?php echo e($gmsuv['suv2']); ?></td>
			                          <td><?php echo e($gmsuv['suv3']); ?></td>
			                          <td><?php echo e($gmsuv['suv4']); ?></td>
			                          <td><?php echo e($gmsuv['suv5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Minivans</th>
			                          <td><?php echo e($gmvan['van1']); ?></td>
			                          <td><?php echo e($gmvan['van2']); ?></td>
			                          <td><?php echo e($gmvan['van3']); ?></td>
			                          <td><?php echo e($gmvan['van4']); ?></td>
			                          <td><?php echo e($gmvan['van5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Trucks</th>
			                          <td><?php echo e($gmtruck['truck1']); ?></td>
			                          <td><?php echo e($gmtruck['truck2']); ?></td>
			                          <td><?php echo e($gmtruck['truck3']); ?></td>
			                          <td><?php echo e($gmtruck['truck4']); ?></td>
			                          <td><?php echo e($gmtruck['truck5']); ?></td>
			                        </tr>
			                        <tr>
			                          <th>Total</th>
			                          <td>
			                          	<?php echo e($gmcars['cars1'] + $gmsuv['suv1'] + $gmvan['van1'] + $gmtruck['truck1']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($gmcars['cars2'] + $gmsuv['suv2'] + $gmvan['van2'] + $gmtruck['truck2']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($gmcars['cars3'] + $gmsuv['suv3'] + $gmvan['van3'] + $gmtruck['truck3']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($gmcars['cars4'] + $gmsuv['suv4'] + $gmvan['van4'] + $gmtruck['truck4']); ?>

			                          </td>
			                          <td>
			                          	<?php echo e($gmcars['cars5'] + $gmsuv['suv5'] + $gmvan['van5'] + $gmtruck['truck5']); ?>

			                          </td>
			                        </tr>
			                      </tbody>
			                    </table>
		                  	</div>
	                      </div>
	                      <div class="tab-pane" id="tab4" aria-labelledby="base-tab4">
	                        <div class="table-responsive">
			                    <table class="table table-bordered table-striped table-xs">
				                    <thead>
				                        <tr>
					                         <th></th>
					                         <th>$0-$10,000</th>
		                                     <th>$10-$15,000</th>
		                                     <th>$15-$20,000</th>
		                                     <th>$20-$25,000</th>
		                                     <th>$25,000+</th>
				                        </tr>
				                      </thead>
				                      <tbody>
				                        <tr>
				                          <th>Cars</th>
				                          <td><?php echo e($wacars['cars1']); ?></td>
				                          <td><?php echo e($wacars['cars2']); ?></td>
				                          <td><?php echo e($wacars['cars3']); ?></td>
				                          <td><?php echo e($wacars['cars4']); ?></td>
				                          <td><?php echo e($wacars['cars5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>SUVs</th>
				                          <td><?php echo e($wasuv['suv1']); ?></td>
				                          <td><?php echo e($wasuv['suv2']); ?></td>
				                          <td><?php echo e($wasuv['suv3']); ?></td>
				                          <td><?php echo e($wasuv['suv4']); ?></td>
				                          <td><?php echo e($wasuv['suv5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>Minivans</th>
				                          <td><?php echo e($wavan['van1']); ?></td>
				                          <td><?php echo e($wavan['van2']); ?></td>
				                          <td><?php echo e($wavan['van3']); ?></td>
				                          <td><?php echo e($wavan['van4']); ?></td>
				                          <td><?php echo e($wavan['van5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>Trucks</th>
				                          <td><?php echo e($watruck['truck1']); ?></td>
				                          <td><?php echo e($watruck['truck2']); ?></td>
				                          <td><?php echo e($watruck['truck3']); ?></td>
				                          <td><?php echo e($watruck['truck4']); ?></td>
				                          <td><?php echo e($watruck['truck5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>Total</th>
				                          <td>
				                          	<?php echo e($wacars['cars1'] + $wasuv['suv1'] + $wavan['van1'] + $watruck['truck1']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($wacars['cars2'] + $wasuv['suv2'] + $wavan['van2'] + $watruck['truck2']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($wacars['cars3'] + $wasuv['suv3'] + $wavan['van3'] + $watruck['truck3']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($wacars['cars4'] + $wasuv['suv4'] + $wavan['van4'] + $watruck['truck4']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($wacars['cars5'] + $wasuv['suv5'] + $wavan['van5'] + $watruck['truck5']); ?>

				                          </td>
				                        </tr>
				                      </tbody>
				                    </table>
			                  	</div>
	                      	</div>
	                      <div class="tab-pane" id="tab5" aria-labelledby="base-tab5">
	                        <div class="table-responsive">
			                    <table class="table table-bordered table-striped table-xs">
				                    <thead>
				                        <tr>
					                         <th></th>
					                         <th>$0-$10,000</th>
		                                     <th>$10-$15,000</th>
		                                     <th>$15-$20,000</th>
		                                     <th>$20-$25,000</th>
		                                     <th>$25,000+</th>
				                        </tr>
				                      </thead>
				                      <tbody>
				                        <tr>
				                          <th>Cars</th>
				                          <td><?php echo e($acars['cars1']); ?></td>
				                          <td><?php echo e($acars['cars2']); ?></td>
				                          <td><?php echo e($acars['cars3']); ?></td>
				                          <td><?php echo e($acars['cars4']); ?></td>
				                          <td><?php echo e($acars['cars5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>SUVs</th>
				                          <td><?php echo e($asuv['suv1']); ?></td>
				                          <td><?php echo e($asuv['suv2']); ?></td>
				                          <td><?php echo e($asuv['suv3']); ?></td>
				                          <td><?php echo e($asuv['suv4']); ?></td>
				                          <td><?php echo e($asuv['suv5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>Minivans</th>
				                          <td><?php echo e($avan['van1']); ?></td>
				                          <td><?php echo e($avan['van2']); ?></td>
				                          <td><?php echo e($avan['van3']); ?></td>
				                          <td><?php echo e($avan['van4']); ?></td>
				                          <td><?php echo e($avan['van5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>Trucks</th>
				                          <td><?php echo e($atruck['truck1']); ?></td>
				                          <td><?php echo e($atruck['truck2']); ?></td>
				                          <td><?php echo e($atruck['truck3']); ?></td>
				                          <td><?php echo e($atruck['truck4']); ?></td>
				                          <td><?php echo e($atruck['truck5']); ?></td>
				                        </tr>
				                        <tr>
				                          <th>Total</th>
				                          <td>
				                          	<?php echo e($acars['cars1'] + $asuv['suv1'] + $avan['van1'] + $atruck['truck1']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($acars['cars2'] + $asuv['suv2'] + $avan['van2'] + $atruck['truck2']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($acars['cars3'] + $asuv['suv3'] + $avan['van3'] + $atruck['truck3']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($acars['cars4'] + $asuv['suv4'] + $avan['van4'] + $atruck['truck4']); ?>

				                          </td>
				                          <td>
				                          	<?php echo e($acars['cars5'] + $asuv['suv5'] + $avan['van5'] + $atruck['truck5']); ?>

				                          </td>
				                        </tr>
				                      </tbody>
				                    </table>
			                  	</div>
	                      	</div>
	                      </div>
	                    </div>

	                </div>
              	</div>
            </div>
          </div>
        </section>
    </div>
</div>



<script src="<?php echo e(asset('admin_assets/js/mainjs/inventory_search.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/tables/datatables/datatable-basic.js')); ?>" type="text/javascript"></script>

<script>


	$('.call-pop-over-function').hover(
		function() {
			var id = $( this ).attr("data-id");
			$("#popover-"+id).popover({ trigger: "hover" });
		}
	);


	$('.call-modal').hover(
		function() {
			var id = $( this ).attr("data-id");
			$("#popover-"+id).popover({ trigger: "hover" });
		}
	);


</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>